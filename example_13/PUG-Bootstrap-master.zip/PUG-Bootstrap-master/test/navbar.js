var assert = require("assert");
var pug = require("pug");
var fs = require("fs");
var path = require("path");

describe("Navbar",function() {

    it("should generate a navbar", function(){
        // var fn = pug.compileFile(path.join(__dirname, "fixtures/navbar","navbar.pug"));
        assert.equal(1,1);
    });

});
