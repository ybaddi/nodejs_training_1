var assert = require("assert");
var pug = require("pug");
var fs = require("fs");
var path = require("path");

describe("List groups",function() {

    it("should generate a list group", function(){
        // var fn = pug.compileFile(path.join(__dirname, "fixtures/list-groups","list-group.pug"));
        assert.equal(1,1);
    });

});
