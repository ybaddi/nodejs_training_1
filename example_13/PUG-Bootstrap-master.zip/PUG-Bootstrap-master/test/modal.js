var assert = require("assert");
var pug = require("pug");
var fs = require("fs");
var path = require("path");

describe("Modal",function() {

    it("should generate a modal", function(){
        // var fn = pug.compileFile(path.join(__dirname, "fixtures/modal","modal.pug"));
        assert.equal(1,1);
    });

});
