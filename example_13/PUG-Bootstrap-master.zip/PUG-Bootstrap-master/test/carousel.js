var pug = require("pug");
var assert = require("assert");
var path = require("path");

describe("Carousel", function() {

});
