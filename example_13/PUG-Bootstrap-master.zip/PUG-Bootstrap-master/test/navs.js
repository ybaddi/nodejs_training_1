var assert = require("assert");
var pug = require("pug");
var fs = require("fs");
var path = require("path");

describe("Navs",function() {

    it("should generate a nav", function(){
        // var fn = pug.compileFile(path.join(__dirname, "fixtures/navs","navs.pug"));
        assert.equal(1,1);
    });

});
