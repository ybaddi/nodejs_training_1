var assert = require("assert");
var pug = require("pug");
var fs = require("fs");
var path = require("path");

describe("Tables",function() {

    it("should generate a table", function(){
        // var fn = pug.compileFile(path.join(__dirname, "fixtures/tables","table.pug"));
        assert.equal(1,1);
    });

});
