var assert = require("assert");
var pug = require("pug");
var fs = require("fs");
var path = require("path");

describe("Dropdowns", function(){
    it("should generate a dropdown", function(){
        // var fn = pug.compileFile(path.join(__dirname, "fixtures/dropdowns","dropdown.pug"));
        assert.equal(true,true);
    });
});
