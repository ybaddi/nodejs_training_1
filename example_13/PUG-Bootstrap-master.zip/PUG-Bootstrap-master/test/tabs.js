var assert = require("assert");
var pug = require("pug");
var fs = require("fs");
var path = require("path");

describe("Tabs",function() {

    it("should generate a tab", function(){
        // var fn = pug.compileFile(path.join(__dirname, "fixtures/tabs","tab.pug"));
        assert.equal(1,1);
    });

});
